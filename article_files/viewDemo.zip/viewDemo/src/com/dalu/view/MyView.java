package com.dalu.view;

import com.example.viewdemo.R;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.util.AttributeSet;
import android.view.View;

public class MyView extends View{
	Paint mPaint ;

	public MyView(Context context, AttributeSet attrs) {
		super(context, attrs);
		mPaint = new Paint();
		TypedArray array = context.obtainStyledAttributes(attrs, R.styleable.MyView);
		int textColor = array.getColor(R.styleable.MyView_textColor, 0XFF00FF00);
		float textSize = array.getDimension(R.styleable.MyView_textSize, 30) ;
		mPaint.setColor(textColor);
		mPaint.setTextSize(textSize);
		array.recycle();
	}
	@Override
	public void onDraw(Canvas canvas){
		super.onDraw(canvas);
		mPaint.setStyle(Style.FILL);
		canvas.drawRect(10, 10, 100, 100, mPaint);
		mPaint.setColor(Color.BLUE);
		canvas.drawText("法胜王佛", 10, 120, mPaint);
	}
}
