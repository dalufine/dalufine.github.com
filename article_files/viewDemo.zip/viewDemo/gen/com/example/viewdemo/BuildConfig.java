/** Automatically generated file. DO NOT MODIFY */
package com.example.viewdemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}