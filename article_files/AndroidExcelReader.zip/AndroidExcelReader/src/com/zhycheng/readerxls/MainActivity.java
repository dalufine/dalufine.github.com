package com.zhycheng.readerxls;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import android.app.Activity;
import android.content.res.AssetManager;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.SimpleAdapter;

public class MainActivity extends Activity {
    /** Called when the activity is first created. */
	
	ArrayList<HashMap<String,String>> al;
	ListView lv;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        lv=(ListView) findViewById(R.id.listView1);
        al=new ArrayList<HashMap<String,String>>();
        AssetManager am=this.getAssets();
        InputStream is=null;
        try {
        	
			is=am.open("data.xls");
			Workbook wb=Workbook.getWorkbook(is);
			Sheet sheet=wb.getSheet(0);
			int row=sheet.getRows();
			HashMap<String,String> hm;
			for(int i=0;i<row;++i)
			{
				Cell cellarea=sheet.getCell(0, i);
				Cell cellschool=sheet.getCell(1, i);
				System.out.println(cellarea.getContents()+":"+cellschool.getContents());
				hm=new HashMap<String,String>();
				hm.put("AREA", cellarea.getContents());
				hm.put("SCHOOL", cellschool.getContents());
				al.add(hm);
			}
			SimpleAdapter sa=new SimpleAdapter(this,al,R.layout.lv_item,new String[]{"AREA","SCHOOL"},new int[]{R.id.tv_area,R.id.tv_school});
			lv.setAdapter(sa);
			 
			 
			 
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
       
        
        
    }
}