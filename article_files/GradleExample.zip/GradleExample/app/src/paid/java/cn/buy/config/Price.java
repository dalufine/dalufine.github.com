package cn.buy.config;

/**
 * Created by Levi on 2017/11/21.
 */

public class Price {
    public static String getName() {
        return "Paid";
    }
}
