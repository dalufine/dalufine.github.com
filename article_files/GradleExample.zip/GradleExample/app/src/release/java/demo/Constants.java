package demo;

public class Constants {

}
