package com.example.sqldemo;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class SqlAdapter extends BaseAdapter {
	private Context mContext;
	private ArrayList<User> datas;

	public SqlAdapter(Context context, ArrayList<User> datas) {
		this.mContext = context;
		this.datas = datas;
	}

	@Override
	public int getCount() {
		if (datas == null) {
			return 0;
		} else
			return datas.size();
	}

	@Override
	public Object getItem(int position) {
		return datas.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder = null;
		if(convertView == null){
			holder = new ViewHolder() ;
			convertView = LayoutInflater.from(mContext).inflate(R.layout.list_item, null);
			holder.uid = (TextView)convertView.findViewById(R.id.uid) ;
			holder.username = (TextView)convertView.findViewById(R.id.username) ;
			holder.password = (TextView)convertView.findViewById(R.id.password) ;
			convertView.setTag(holder);
		}else{
			holder = (ViewHolder) convertView.getTag();
		}
		holder.uid.setText(datas.get(position).getUid()+"");
		holder.username.setText(datas.get(position).getUsername());
		holder.password.setText(datas.get(position).getPassword());
		return convertView;
	}

	class ViewHolder {
		TextView uid;
		TextView username;
		TextView password;
	}

}
