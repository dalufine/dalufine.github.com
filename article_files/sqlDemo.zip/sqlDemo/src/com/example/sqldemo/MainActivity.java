package com.example.sqldemo;

import java.util.ArrayList;

import javax.security.auth.PrivateCredentialPermission;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.R.integer;
import android.app.Activity;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends Activity implements OnClickListener {
	private ListView lv;
	private EditText et_uid, et_username, et_password;
	private Button bt_insert, bt_del, bt_update, bt_search;
	private ArrayList<User> datas = null;
	private SqlAdapter adapter = null;
	private SQLiteDatabase db = null;
	private static final int REFRESH = 4;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		datas = new ArrayList<User>();
		init();
		initData();
		DatabaseHelper database = new DatabaseHelper(this);
		db = database.getWritableDatabase();

	}

	private Handler handler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			switch (msg.what) {
			case REFRESH:
				adapter.notifyDataSetChanged();
				break;
			default:
				break;
			}
		}
	};

	private void initData() {
		adapter = new SqlAdapter(this, datas);
		lv.setAdapter(adapter);
	}

	private void init() {
		lv = (ListView) findViewById(R.id.lv);
		et_uid = (EditText) findViewById(R.id.et_uid);
		et_username = (EditText) findViewById(R.id.et_username);
		et_password = (EditText) findViewById(R.id.et_password);
		bt_insert = (Button) findViewById(R.id.insert);
		bt_del = (Button) findViewById(R.id.del);
		bt_update = (Button) findViewById(R.id.update);
		bt_search = (Button) findViewById(R.id.search);
		bt_insert.setOnClickListener(this);
		bt_del.setOnClickListener(this);
		bt_update.setOnClickListener(this);
		bt_search.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		String uidString = et_uid.getText().toString().trim();
		String usernameString = et_username.getText().toString().trim();
		String passwordString = et_password.getText().toString().trim();
		System.out.println(uidString+usernameString+passwordString) ;
		if (TextUtils.isEmpty(uidString) && TextUtils.isEmpty(usernameString)
				&& TextUtils.isEmpty(passwordString)) {
			Toast.makeText(this, "null", Toast.LENGTH_SHORT).show();
			return;
		}
		switch (v.getId()) {
		case R.id.insert:
			insert(usernameString, passwordString);
			searchAll() ;
			break;
		case R.id.del:
			del(uidString);
			searchAll() ;
			break;
		case R.id.update:
			update(uidString, usernameString, passwordString);
			searchAll() ;
			break;
		case R.id.search:
			searchAll() ;
			break;

		default:
			break;
		}
	}

	private void insert(String username, String password) {
		ContentValues cv = new ContentValues();
		cv.put("username", username);// 添加用户名
		cv.put("password", password); // 添加密码
		db.insert("user", null, cv);// 执行插入操作
	}

	private void del(String uid) {
		String whereClause = "uid=?";// 删除的条件
		String[] whereArgs = { uid };// 删除的条件参数
		db.delete("user", whereClause, whereArgs);
	}

	private void update(String uid, String username, String password) {
		ContentValues cv = new ContentValues();// 实例化ContentValues
		cv.put("username", username);// 添加要更改的字段及内容
		cv.put("password", password);// 添加要更改的字段及内容
		String whereClause = "uid=?";// 删除的条件
		String[] whereArgs = { uid };// 删除的条件参数
		db.update("user", cv, whereClause, whereArgs);
	}
	private void searchAll(){
		datas.clear();
		//Cursor c = db.query("user", null, null, null, null, null, null) ;
		Cursor c = db.rawQuery("select * from user ",null);
		if(c.moveToFirst()){
			System.out.println("---------------------------------"+c.getCount()) ;
			for(int i=0;i<c.getCount();i++){
				User user = new User() ;
				user.setUid(c.getInt(c.getColumnIndex("uid")));
				user.setUsername(c.getString(c.getColumnIndex("username")));
				user.setPassword(c.getString(c.getColumnIndex("password")));
				datas.add(user) ;
				c.move(1) ;
			}
		}
		handler.sendEmptyMessage(REFRESH) ;
	}
}
