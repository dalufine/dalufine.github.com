package com.example.sqldemo;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper{
	private static final String DB_NAME = "sqldemo" ;
	private static final int version = 1 ;
	public DatabaseHelper(Context context){
		super(context, DB_NAME, null, version);
	}
	@Override
	public void onCreate(SQLiteDatabase db) {
		String sql = "create table user(uid integer primary key, username varchar(40) not null,password varchar(40) not null)" ;
		db.execSQL(sql);
		
	}
	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		
	}
}
